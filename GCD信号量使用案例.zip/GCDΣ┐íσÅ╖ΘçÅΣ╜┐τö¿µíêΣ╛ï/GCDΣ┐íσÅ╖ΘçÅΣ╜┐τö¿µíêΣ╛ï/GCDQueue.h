//
//  GCDQueue.h
//  GCD信号量使用案例
//
//  Created by 魏琦 on 16/8/2.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GCDQueue : NSObject

+(void)executeInGlobalQueue:(dispatch_block_t)block;
+(void)executeInMainQueue:(dispatch_block_t)block;

@end
