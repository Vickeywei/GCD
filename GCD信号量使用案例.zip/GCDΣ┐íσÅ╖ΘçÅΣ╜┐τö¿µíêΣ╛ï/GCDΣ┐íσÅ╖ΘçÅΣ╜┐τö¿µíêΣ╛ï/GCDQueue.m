//
//  GCDQueue.m
//  GCD信号量使用案例
//
//  Created by 魏琦 on 16/8/2.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

#import "GCDQueue.h"
static dispatch_queue_t globalQueue;
static dispatch_queue_t mainQueue;

@implementation GCDQueue
+ (void)executeInGlobalQueue:(dispatch_block_t)block {
    if (!globalQueue) {
       globalQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    }
    dispatch_async(globalQueue, block);
}

+ (void)executeInMainQueue:(dispatch_block_t)block {
   
      mainQueue = dispatch_get_main_queue();  
    
    
    dispatch_async(mainQueue, block);
    
}
@end

