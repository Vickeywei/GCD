//
//  GCDSemaphore.m
//  GCD信号量使用案例
//
//  Created by 魏琦 on 16/8/2.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

#import "GCDSemaphore.h"
@interface GCDSemaphore ()
@property (nonatomic, strong) dispatch_semaphore_t semaphore;


@end

@implementation GCDSemaphore
- (instancetype)init {
    if (self = [super init]) {
        _semaphore = dispatch_semaphore_create(0);
    }
    return self;
}

- (void)wait {
    dispatch_semaphore_wait(_semaphore, DISPATCH_TIME_FOREVER);
}

- (void)signal {
    dispatch_semaphore_signal(_semaphore);
    
}

@end
