//
//  ViewController.m
//  GCD信号量使用案例
//
//  Created by 魏琦 on 16/8/2.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

#import "ViewController.h"
#import "GCDSemaphore.h"
#import "GCDQueue.h"

@interface ViewController ()
@property (nonatomic, strong) UIImageView* view1;
@property (nonatomic, strong) UIImageView* view2;
@property (nonatomic, strong) UIImageView* view3;



@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view1 = [self createImageViewWithFrame:CGRectMake(0, 64, 100, 100)];
    self.view2 = [self createImageViewWithFrame:CGRectMake(120, 64, 100, 100)];
    self.view3 = [self createImageViewWithFrame:CGRectMake(240, 64, 100, 100)];
    
    // 初始化三个网址
    NSString *net1 = @"http://ww2.sinaimg.cn/large/68d8771bgw1eupg6yqzzvj20m80etgo5.jpg";
    NSString *net2 = @"http://ww4.sinaimg.cn/large/68d8771bgw1eupg7b3r92j20eu0m7n07.jpg";
    NSString *net3 = @"http://ww3.sinaimg.cn/large/68d8771bgw1eupg7oceo7j20cy0ihn27.jpg";
    
    // 初始化信号量
    GCDSemaphore *semaphore = [[GCDSemaphore alloc] init];
    
    // 图片下载
    [GCDQueue executeInGlobalQueue:^{
        NSLog(@"%@",[NSThread currentThread]);
        UIImage *image1 = [self accessDataImageByNetString:net1];
       // NSLog(@"image1:%f,%f",image1.size.width,image1.size.height);
       // [semaphore wait];
        [GCDQueue executeInMainQueue:^{
            
            // 动画
            [UIView animateWithDuration:2.f animations:^{
                self.view1.image = image1;
                self.view1.alpha = 1.f;
                
            } completion:^(BOOL finished) {
                // 第一张图片完全显示完毕发送信号
                [semaphore signal];
            }];
        }];
    }];
    
    [GCDQueue executeInGlobalQueue:^{
        NSLog(@"%@",[NSThread currentThread]);
        
        UIImage *image2 = [self accessDataImageByNetString:net2];
        //  NSLog(@"image2:%f,%f",image2.size.width,image2.size.height);
        // 阻塞线程，等待第一张图片的下载完毕执行动画
        [semaphore wait];
        
        [GCDQueue executeInMainQueue:^{
            [UIView animateWithDuration:2.f animations:^{
                
                self.view2.image = image2;
                self.view2.alpha = 1.f;
            } completion:^(BOOL finished) {
               [semaphore signal];
            }];
        }];
    }];
    
    [GCDQueue executeInGlobalQueue:^{
        NSLog(@"%@",[NSThread currentThread]);
        UIImage *image3 = [self accessDataImageByNetString:net3];
       // NSLog(@"image3:%f,%f",image3.size.width,image3.size.height);
        // 阻塞线程，等待第二张图片下载完毕执行动画
        [semaphore wait];
        [GCDQueue executeInMainQueue:^{
            
            [UIView animateWithDuration:2.f animations:^{
                self.view3.image = image3;
                self.view3.alpha = 1.f;
            }completion:^(BOOL finished) {
                //
                [semaphore signal];
            }];
        }];
    }];
    // Do any additional setup after loading the view, typically from a nib.
}
// 初始化三个imageView用来显示图片




/**
 *  获取网络图片
 *
 *  @param netString 图片网址
 *
 *  @return 图片
 */
- (UIImage *)accessDataImageByNetString:(NSString *)netString
{
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:netString]];
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    UIImage *image = [[UIImage alloc] initWithData:data];
    return image;
}

/**
 *  创建ImageView
 *
 *  @param frame frame
 *
 *  @return imageView
 */
- (UIImageView *)createImageViewWithFrame:(CGRect)frame
{
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:frame];
    imageView.alpha = 0.f;
    [self.view addSubview:imageView];
    return imageView;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
