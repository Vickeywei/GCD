//
//  NSOperationViewController.swift
//  NSOperation
//
//  Created by 魏琦 on 16/7/11.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

import UIKit

public class NSOperationViewController: UIViewController {
    var operation : NSBlockOperation!
    public var  str: String!
    var operationQueue: NSOperationQueue!
    override public func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.cyanColor();
        self.navigationItem.title = str
        if str == "NSOperation" {
            operation = NSBlockOperation.init(block: {
                let array: Array = ["1",123,"456","我","fghjk"]
                
                let queue: dispatch_queue_t = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
                
                dispatch_apply(array.count,queue, { (i) in
                    let name = array[i]
                    print(name)
                })
                
            })
            /**
             *  swift中去掉了NSInvocationOperation这个子类
             */
            operation.addExecutionBlock {
                print("我是第二个任务")
            }
            operation.start()
        }
        else {
            operationQueue = NSOperationQueue.init()
            
            let operation:NSBlockOperation = NSBlockOperation.init(block: { 
                print("我是queue中的任务")
                self.operationQueue.cancelAllOperations()
                
            })
            
            
            
            let operation2:NSBlockOperation = NSBlockOperation.init(block: {
                
                for item in 1 ..< 10000  {
                    print(item)
                 
                    
                }
               
            })
            operationQueue.addOperation(operation)
           
           
            operationQueue.addOperation(operation2)
            
            
        }
       
        
        
        
        
        
        
    }
    
    

}
