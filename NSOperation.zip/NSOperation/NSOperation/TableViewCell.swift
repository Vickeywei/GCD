//
//  TableViewCell.swift
//  NSOperation
//
//  Created by 魏琦 on 16/7/11.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

import UIKit

public class TableViewCell: UITableViewCell {
    
    var titleLabel : UILabel!
    var detailLabel :UILabel!
    
    public func setLabeText(text : String ,detailText:String) {
        titleLabel = UILabel.init(frame: CGRectMake(10, 10,180, 30))
        titleLabel.text = text
        titleLabel.font = UIFont.systemFontOfSize(14)
        self.contentView .addSubview(titleLabel)
        detailLabel = UILabel.init(frame: CGRectMake(self.contentView.bounds.size.width-130, 10, 120, 30))
        self.contentView.addSubview(detailLabel)
        detailLabel.text = detailText;
        detailLabel.font = UIFont.systemFontOfSize(12)
    }
    
    

}
