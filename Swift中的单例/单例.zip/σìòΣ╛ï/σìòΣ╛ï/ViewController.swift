//
//  ViewController.swift
//  单例
//
//  Created by 魏琦 on 16/7/27.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let api = APIManager.sharedInstance
        api.width = 200.0
        print(api.width)
        let api2 = APIManager()
        print(api2.width)
//        
//        let shareadInstance = TheOneAndOnlyKraken();
//        shareadInstance.width = 200.1
//        let  shareadInstance2  = TheOneAndOnlyKraken();
//        print("%f", shareadInstance2.width)
        
        
    
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
        
    
        
        // Dispose of any resources that can be recreated.
    }


}
class TheOneAndOnlyKraken{
       var width:CGFloat?
       class var sharedInstance:TheOneAndOnlyKraken{
      
        struct Static{
            static var onceToken: dispatch_once_t = 0
            static var instance: TheOneAndOnlyKraken? = nil
            }
        dispatch_once(&Static.onceToken){
        Static.instance = TheOneAndOnlyKraken()
            }
        return Static.instance!
    }
}


class APIManager{
    var width:CGFloat?
    static let sharedInstance = APIManager()
    private  init() {}
}



