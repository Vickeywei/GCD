//
//  ViewController.swift
//  git
//
//  Created by 魏琦 on 16/7/7.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController  {
    var  collectionView: UICollectionView!
    var  collectionViewFlowLayOut : UICollectionViewFlowLayout!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.redColor()
        self.collectionViewFlowLayOut = UICollectionViewFlowLayout.init()
        self.collectionViewFlowLayOut.itemSize = CGSizeMake(80, 80)
        self.collectionViewFlowLayOut.minimumLineSpacing = 5
        self.collectionViewFlowLayOut.minimumInteritemSpacing = 5
        self.collectionViewFlowLayOut.sectionInset = UIEdgeInsetsMake(5, 5, 5, 5)
        self.collectionView = UICollectionView.init(frame:CGRectMake(0, 0,self.view.frame.size.width , self.view.frame.size.height) ,collectionViewLayout: self.collectionViewFlowLayOut)
        self.view .addSubview(self.collectionView)
        self.collectionView .registerClass(UICollectionViewCell .classForCoder(), forCellWithReuseIdentifier: "cell")
        self.collectionView.delegate = self
        self.collectionView.dataSource  = self
        
        
    
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
extension ViewController:UICollectionViewDelegate,UICollectionViewDataSource{
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return 20
    }
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 4
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("cell", forIndexPath: indexPath)
        cell.backgroundColor =         UIColor.init(red: (CGFloat(arc4random()%255)/256.0), green: (CGFloat(arc4random()%255)/256.0), blue: (CGFloat(arc4random()%255)/256.0), alpha: 1)
        return cell
    }
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
       var array : Array = ["123", "hello", 1.0,1.2, "我是对象","567",2.0,3.0]
//        
////        
        let myqueue : dispatch_queue_t = // dispatch_get_main_queue()
            dispatch_queue_create("com.weiqi.queue",nil);
        dispatch_apply(array.count,myqueue) { (i) in
            let name = array[i]
            print(name)
        }
        print("完成");
        
//        let myQueue : dispatch_queue_t = dispatch_queue_create("com.vicky.com",DISPATCH_QUEUE_CONCURRENT);
//        dispatch_async(myQueue) { 
//            let name = array[0]
//                print(name)
//        }
//        dispatch_async(myQueue) {
//            let name = array[1]
//            print(name)
//        }
//        dispatch_async(myQueue) {
//            let name = array[2]
//            print(name)
//        }
//        dispatch_async(myQueue) {
//            let name = array[3]
//            print(name)
//        }
////        dispatch_barrier_async(myQueue) {
////             array.insert("wwwwwww", atIndex: 4)
////        }
////        //写入数据
//        dispatch_async(myQueue) {
//
//             array.insert("wwwwwww", atIndex: 4)
//        }
//        dispatch_async(myQueue) {
//            let name = array[4]
//            print(array.indexOf(name), name)
//            
//        }
//        dispatch_async(myQueue) {
//            let name = array[5]
//            print(name)
//        }
//        dispatch_async(myQueue) {
//            let name = array[6]
//            print(name)
//        }
//        let name3 = array[3]
//        
//        print(name3,array)  
//        
    }
   
    
}



