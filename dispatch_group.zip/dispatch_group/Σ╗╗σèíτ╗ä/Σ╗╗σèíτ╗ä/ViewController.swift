//
//  ViewController.swift
//  任务组
//
//  Created by 魏琦 on 16/7/27.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let group  = dispatch_group_create()
    let queue  = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
    

    override func viewDidLoad() {
        super.viewDidLoad()
      
        //如果我们要实现比如app工场的banner和商品的数据请求,完成后一并刷新UI界面,就可以采用该方式
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
//这个相当于NSOperation中的依赖关系
    @IBAction func networkingAction(sender: AnyObject) {
        dispatch_group_async(group, queue) {
            print("执行网络请求,去请求banner数据,并进行包装")
        }
        dispatch_group_async(group, queue) {
            print("执行网络请求,去请求商品列表数据,并进行包装")
        }
        //这个会在前面两个组任务完成后调用,如果有什么特殊的需求可以直接将这些通知调度到你想操作的队列上.
        dispatch_group_notify(group, dispatch_get_main_queue()) {
            print("对数据进行持久化,刷新UI")
//            dispatch_async(dispatch_get_main_queue(), {
//                print("刷新UI界面")
//            })
        }
    }

}

