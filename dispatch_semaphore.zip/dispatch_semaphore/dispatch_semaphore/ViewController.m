//
//  ViewController.m
//  dispatch_semaphore
//
//  Created by 魏琦 on 16/8/2.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, strong) dispatch_semaphore_t semaphore ;
@property (nonatomic, strong) dispatch_group_t group;
@property (nonatomic, strong) dispatch_queue_t queue;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
//    NSMutableArray* array = [[NSMutableArray alloc] init];
//    for (int i = 0; i <= 100000; i ++) {
//        dispatch_async(self.queue, ^{
              //信号量减1等于0,其他线程等待,只有当信号量大于等于1时才能进行访问.避免数据竞争
//            dispatch_semaphore_wait(self.semaphore, DISPATCH_TIME_FOREVER);
//            
//            [array addObject:[NSNumber numberWithInt:i]];
              //当线程操作执行完毕后,为了能够保证后面的线程能够继续操作和访问数据,必须将信号量加1
//            dispatch_semaphore_signal(self.semaphore);
//        });
//    }
//    printf("%lu",(unsigned long)array.count);
//    __block int count=1000;
//    for (int i=0; i<100; i++) {
//        //信号量减1，则信号量小于等于0，此时就会阻塞该线程。
//        /**
//         *递减计数信号量。如果结果值小于等于零,这个函数返回之前等待一个信号发生。
//         */
//        dispatch_semaphore_wait(self.semaphore, DISPATCH_TIME_FOREVER);
//        dispatch_group_async(self.group, self.queue, ^{
//            int value = (arc4random() % 4) + 6;
//            NSLog(@"%d-%d= %d",count,value,count-value);
//            count=count-value;
//            //增加计数信号量,并发送信号
//            dispatch_semaphore_signal(self.semaphore);
//        });  
//    }
    
    
    
    dispatch_semaphore_wait(self.semaphore, DISPATCH_TIME_FOREVER);
    dispatch_group_async(self.group, self.queue, ^{
        for (int i = 0; i < 1000; i ++) {
             NSLog(@"写入数据库");
        }
       
        dispatch_semaphore_signal(self.semaphore);
    });
//
    [NSThread detachNewThreadSelector:@selector(runData) toTarget:self withObject:nil];
    
    
    
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)runData{
    dispatch_semaphore_wait(self.semaphore, DISPATCH_TIME_FOREVER);
    dispatch_group_async(self.group, self.queue, ^{
        for (int i = 0; i < 1000; i ++) {
            NSLog(@"读取数据库");
        }
        dispatch_semaphore_signal(self.semaphore);
    });
}

- (dispatch_semaphore_t)semaphore {
    if (!_semaphore){
        //创建信号计数量,并设置初始计数值
        _semaphore= dispatch_semaphore_create(1);
        
    }
    return _semaphore;
}

- (dispatch_group_t)group {
    if (!_group) {
        _group = dispatch_group_create();
    }
    return _group;
}

- (dispatch_queue_t)queue {
    if (!_queue) {
       _queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    }
    return _queue;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
