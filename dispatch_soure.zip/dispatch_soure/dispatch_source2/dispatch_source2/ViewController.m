//
//  ViewController.m
//  dispatch_source2
//
//  Created by 魏琦 on 16/8/5.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIProgressView *progress;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    dispatch_source_t source = dispatch_source_create(DISPATCH_SOURCE_TYPE_DATA_ADD, 0, 0, dispatch_get_main_queue());
    __block long totalComple = 0;
    dispatch_source_set_event_handler(source, ^{
        long value = dispatch_source_get_data(source);
       // NSLog(@"%lu",value);
        
        totalComple += value;
        NSLog(@"%lu",totalComple);
        

        self.progress.progress = totalComple/100.0f;
        NSLog(@"%f",self.progress.progress);
        
        
    });
    dispatch_resume(source);

    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(queue, ^{
        for (int i = 0; i < 100; i ++) {
            dispatch_source_merge_data(source, 1);
            usleep(20000);
        }
    });
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
