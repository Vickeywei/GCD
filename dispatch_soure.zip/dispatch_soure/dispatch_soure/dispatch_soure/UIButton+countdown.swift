//
//  UIButton+countdown.swift
//  dispatch_soure
//
//  Created by 魏琦 on 16/7/28.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

import UIKit
extension UIButton {
    func regisButton(startTime:Int ,title:String,countDownTitle:String,mainColor:UIColor,  countColor:UIColor) {
        var timeOut = startTime
        let queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
        //创建source事件
        let timer:dispatch_source_t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, queue)
        //设置timer ,1开始时间,间隔时间和延迟时间
        dispatch_source_set_timer(timer, dispatch_walltime(nil, 0), NSEC_PER_SEC, 0)
        //用dispatch_source_set_event_handler设置dispatch source的事件处理器
        dispatch_source_set_event_handler(timer) {
            if timeOut <= 0 {
                dispatch_source_cancel(timer)
                dispatch_async(dispatch_get_main_queue(), { 
                    self.backgroundColor = mainColor
                    self.setTitle(title as String, forState: UIControlState.Normal)
                    self.userInteractionEnabled = true
                })
            }
            else {
                let allTime = timeOut+1
                let seconds = timeOut%allTime
                let timeString = String(format: "%0.2d",seconds)
                dispatch_async(dispatch_get_main_queue(), { 
                    self.backgroundColor = countColor
                    self.setTitle(timeString+countDownTitle, forState: UIControlState.Normal)
                    self.userInteractionEnabled = false
                })
                timeOut -= 1;
                
            }
        }
        dispatch_resume(timer);
        
    }
}