//
//  ViewController.swift
//  dispatch_soure
//
//  Created by 魏琦 on 16/7/28.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let width = UIScreen.mainScreen().bounds.size.width;
    let height = UIScreen.mainScreen().bounds.size.height;
  

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        /**
         public var DISPATCH_SOURCE_TYPE_DATA_ADD: dispatch_source_type_t { get }
         
         public var DISPATCH_SOURCE_TYPE_DATA_OR: dispatch_source_type_t { get }
         
         public var DISPATCH_SOURCE_TYPE_MACH_RECV: dispatch_source_type_t { get } mach端口接收
         
         public var DISPATCH_SOURCE_TYPE_MACH_SEND: dispatch_source_type_t { get } mach端口发送
         
         public var DISPATCH_SOURCE_TYPE_MEMORYPRESSURE: dispatch_source_type_t { get }检测内存压力
         
         public var DISPATCH_SOURCE_TYPE_PROC: dispatch_source_type_t { get } 监视进程
         
         public var DISPATCH_SOURCE_TYPE_READ: dispatch_source_type_t { get } 读取文件映像
         
         public var DISPATCH_SOURCE_TYPE_SIGNAL: dispatch_source_type_t { get }接收信号
         
         public var DISPATCH_SOURCE_TYPE_TIMER: dispatch_source_type_t { get }//定时器
         
         public var DISPATCH_SOURCE_TYPE_VNODE: dispatch_source_type_t { get }文件系统变更
         
         public var DISPATCH_SOURCE_TYPE_WRITE: dispatch_source_type_t { get }//写入文件映像
         
         DISPATCH_SOURCE_TYPE_DATA_ADD 和 DISPATCH_SOURCE_TYPE_DATA_OR.用户事件源有个 unsigned long data属性，我们将一个 unsigned long传入 dispatch_source_merge_data。当使用 _ADD版本时，事件在联结时会把这些数字相加。当使用 _OR版本时，事件在联结时会把这些数字逻辑与运算。
         
         - parameter sender: <#sender description#>
         */
    }

    @IBAction func regisAction(sender: AnyObject) {
        let button:UIButton = sender as! UIButton
        button.regisButton(60, title:"获取验证码", countDownTitle:"重新获取", mainColor: UIColor.cyanColor(), countColor: UIColor.brownColor())
        DISPATCH_SOURCE_TYPE_PROC
        
    }

}

