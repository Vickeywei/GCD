//
//  ViewController.swift
//  同步和异步
//
//  Created by 魏琦 on 16/7/26.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let queue = dispatch_get_main_queue()
    let serailQueue = dispatch_queue_create("com.serail.queue", DISPATCH_QUEUE_SERIAL)
    let courrentQueue = dispatch_queue_create("con.concurrent.Queue", DISPATCH_QUEUE_CONCURRENT)
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func action1(sender: AnyObject) {
        /**
         *  主线程同步任务,锁死主线程
         */
        dispatch_sync(queue) {
            print(NSThread.currentThread());
            
        }
    }

    @IBAction func action2(sender: AnyObject) {
        /**
         主队列异步任务 ,串行执行
         */
        dispatch_async(queue) {
            for _ in 1...1000 {
             print("1234567",NSThread.currentThread());
            }
            
            
        }
        dispatch_async(queue) {
           print(NSThread.currentThread());
            
        }
        dispatch_async(queue) {
            print("1234567",NSThread.currentThread());
            
        }
    }
    
    @IBAction func action3(sender: AnyObject) {
        //串行队列同步任务(当前线程为主线程),会在当前线程执行,如果是子线程,会在子线程,指向当前线程
        dispatch_sync(serailQueue) { 
             print(NSThread.currentThread());
        }
        dispatch_sync(serailQueue) {
            print("1234567",NSThread.currentThread());
            
        }
    }
    
    @IBAction func action4(sender: AnyObject) {
        //串行队列异步任务(当前线程为主线程),会开辟新的线程去执行,按照先进先出原则执行
        dispatch_async(serailQueue) {
            for _ in 1...100 {
                print("1234567",NSThread.currentThread());
            }
        }
        dispatch_async(serailQueue) {
            print(NSThread.currentThread());
            
        }
        dispatch_async(serailQueue) {
            print("1234",NSThread.currentThread());
            
        }
    }
    
    
    @IBAction func action5(sender: AnyObject) {
        //并发队列提交同步任务(会在主线程执行),也是指向当前线程,(如果是子线程, 会在子线程执行,始终指向当前线程)
        dispatch_sync(courrentQueue) {
            for _ in 1...100 {
                print("1234567",NSThread.currentThread());
            }
        }
        dispatch_sync(courrentQueue) {
            print(NSThread.currentThread());
            
        }
        dispatch_sync(courrentQueue) {
            print("1234",NSThread.currentThread());
            
        }
    }
    
    
    @IBAction func action6(sender: AnyObject) {
        //并发队列提交异步任务(会开辟新的线程去执行),无论是否是主线程还是子线程都会开辟线程
        dispatch_async(courrentQueue) {
            for _ in 1...100 {
                print("1234567",NSThread.currentThread());
            }
        }
        dispatch_async(courrentQueue) {
            print(NSThread.currentThread());
            
        }
        dispatch_async(courrentQueue) {
            print("1234",NSThread.currentThread());
            
        }
    }
    
    
    @IBAction func action7(sender: AnyObject) {
        //子线程的串行队列同步任务,不会开辟新的线程,串行执行
        let thread7 = NSThread.init(target:self, selector:#selector(self.thread7Action), object: nil);
        thread7.start()
    }
    
    
    @IBAction func action8(sender: AnyObject) {
        //子线程的串行队列异步任务,会开辟新的线程去执行,串行执行
        let thread8 = NSThread.init(target:self, selector:#selector(self.thread8Action), object: nil);
        thread8.start()
    }
    
    
    @IBAction func action9(sender: AnyObject) {
        //子线程的并发队列同步任务,不会开辟新的线程,,因为没有开辟线程所以,任务的执行得等前面的任务执行完毕才能执行
        _ = NSThread.detachNewThreadSelector(#selector(self.thread9Action), toTarget: self, withObject: nil)
    }
    
    @IBAction func action10(sender: AnyObject) {
        //子线程的并发队列异步任务,会开启新的线程去执行,并发执行
        _ = NSThread.detachNewThreadSelector(#selector(self.thread10Action), toTarget: self, withObject: nil)
    }
    
    
    @IBAction func action11(sender: AnyObject) {
        //主线程锁死
        dispatch_async(dispatch_get_main_queue()) {
            print(NSThread.currentThread())
            dispatch_sync(dispatch_get_main_queue(), { 
                print("锁死")
            })
        }
    }
    
    @objc private func thread7Action(){
        print("123",NSThread.currentThread());
        dispatch_sync(serailQueue) {
            print(NSThread.currentThread());
        }
        dispatch_sync(serailQueue) {
            print("1234567",NSThread.currentThread());
            
        }
    }
    @objc private func thread8Action(){
         print("12345679",NSThread.currentThread());
        dispatch_async(serailQueue) {
            for _ in 1...100 {
                print("1234567",NSThread.currentThread());
            }
        }
        dispatch_async(serailQueue) {
            print(NSThread.currentThread());
            
        }
        dispatch_async(serailQueue) {
            print("1234",NSThread.currentThread());
            
        }
        
    }
    @objc private func thread9Action(){
        print("12345",NSThread.currentThread());
        dispatch_sync(courrentQueue) {
            for _ in 1...100 {
                print("1234567",NSThread.currentThread());
            }
        }
        dispatch_sync(courrentQueue) {
            print(NSThread.currentThread());
            
        }
        dispatch_sync(courrentQueue) {
            print("1234",NSThread.currentThread());
            
        }
        
    }
    @objc private func thread10Action(){
        dispatch_async(courrentQueue) {
            for _ in 1...100 {
                print("1234567",NSThread.currentThread());
            }
        }
        dispatch_async(courrentQueue) {
            print(NSThread.currentThread());
            
        }
        dispatch_async(courrentQueue) {
            print("1234",NSThread.currentThread());
            
        }
    }

    
}

