//
//  ViewController.swift
//  延迟执行
//
//  Created by 魏琦 on 16/7/26.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    /// swift当中去掉了宏定义,用常量来表示
    let mainQueue = dispatch_get_main_queue()
    let globalQueue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
    let serialQueue = dispatch_queue_create("com.serial.queue", DISPATCH_QUEUE_SERIAL)//oc中第二个参数也可为NULL
    let concurrentQueue = dispatch_queue_create("com.concurrent.queue", DISPATCH_QUEUE_CONCURRENT)
    let time = dispatch_time(DISPATCH_TIME_NOW, Int64(5*Double(NSEC_PER_SEC)))
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    //主队列延迟执行
    @IBAction func action1(sender: AnyObject) {
        
        dispatch_after(time, mainQueue) {
            NSLog("%@", NSThread.currentThread());
        }
        dispatch_async(mainQueue) { 
           NSLog("123456,%@",NSThread.currentThread())
        }
        
    }

    //串行队列延迟执行,会开辟线程,dispatch_after函数与三秒后用dispatch_async将任务提交到队列中一致
    @IBAction func action2(sender: AnyObject) {
        dispatch_after(time, serialQueue) {
            NSLog("%@", NSThread.currentThread());
        }
        dispatch_async(serialQueue) {
            NSLog("123456,%@",NSThread.currentThread())
        }
        
        
    }
    

    //验证是经过特定延时后才将block提交到队列中的
    @IBAction func action4(sender: AnyObject) {
        dispatch_after(time, globalQueue) {
            NSLog("%@", NSThread.currentThread());
        }
        dispatch_sync(globalQueue) {
            NSLog("123456,%@",NSThread.currentThread())
        }
    }
    
    @IBAction func action5(sender: AnyObject) {
        dispatch_after(time, concurrentQueue) {
            NSLog("%@", NSThread.currentThread());
        }
        dispatch_sync(concurrentQueue) {
            NSLog("123456,%@",NSThread.currentThread())
        }
    }
    
    /**
     *  子线程
     */
    

    //子线程提交任务到主队列,主线程执行
    @IBAction func action6(sender: AnyObject) {
        let thread1 = NSThread.init(target: self, selector:#selector(self.run), object: nil);
        thread1.start();
        
    }
    //子线程提交任务到串行队列,会开辟新的线程执行.
    @IBAction func action7(sender: AnyObject) {
        let thread1 = NSThread.init(target: self, selector:#selector(self.run2), object: nil);
        thread1.start();
        
    }
    //子线程提交任务到全局并发队列,会开辟先得线程执行.
    @IBAction func action8(sender: AnyObject) {
        let thread1 = NSThread.init(target: self, selector:#selector(self.run3), object: nil);
        thread1.start();
        
    }
    //子线程提交任务到全局并发队列,会开辟先得线程执行.
    @IBAction func action9(sender: AnyObject) {
        let thread1 = NSThread.init(target: self, selector:#selector(self.run4), object: nil);
        thread1.start();
       
    }
    @objc private func run() {
        dispatch_after(time, mainQueue) {
            NSLog("%@", NSThread.currentThread());
        }
        dispatch_sync(mainQueue) {
            NSLog("123456,%@",NSThread.currentThread())
        }
    }
    @objc private func run2() {
        NSLog("123456789,%@",NSThread.currentThread())
        dispatch_after(time, serialQueue) {
            //NSLog("%@", NSThread.currentThread());
            self.view.backgroundColor = UIColor.greenColor()
        }
        dispatch_sync(serialQueue) {
            NSLog("123456,%@",NSThread.currentThread())
        }
    }
    @objc private func run3() {
         NSLog("123456789,%@",NSThread.currentThread())
        dispatch_after(time, globalQueue) {
            NSLog("%@", NSThread.currentThread());
        }
        dispatch_sync(globalQueue) {
            NSLog("123456,%@",NSThread.currentThread())
        }
    }
    @objc private func run4() {
        NSLog("123456789,%@",NSThread.currentThread())
        dispatch_after(time, concurrentQueue) {
            NSLog("%@", NSThread.currentThread());
        }
//        dispatch_sync(concurrentQueue) {
//           
//        }
        let blcok = {
             NSLog("123456,%@",NSThread.currentThread())
        }
        dispatch_sync(concurrentQueue, blcok)
    }
    
}

