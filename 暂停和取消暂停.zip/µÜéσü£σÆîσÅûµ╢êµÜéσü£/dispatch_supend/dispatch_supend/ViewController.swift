//
//  ViewController.swift
//  dispatch_supend
//
//  Created by 魏琦 on 16/7/28.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var orangesAreOrange = true
    

    let queue = dispatch_queue_create("com.vicky.queue", nil)
    override func viewDidLoad() {
        super.viewDidLoad()
        let block = {
            (a:Int , b:Int) ->Bool in
            return a > b
        }
        print(block(3,5))
        
        
        let block1 = {
            (str : String) ->String in
            var str1:String = ""
            str1 =  str1.stringByAppendingString(str)
            return str1;
            
        }
        NSLog("%@", block1("我是vicky"))
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func action1(sender: AnyObject) {
        let blcok = {
            NSThread.sleepForTimeInterval(5)
            print("After 5 seconds...")
        }
        dispatch_async(queue, blcok)
        
        let block2 = {
            NSThread.sleepForTimeInterval(5)
            print("After 5 seconds again...")
        }
        dispatch_async(queue, block2)
        
        print("sleep 1 second...")
        NSThread.sleepForTimeInterval(1)
        
        //挂起队列
        dispatch_suspend(queue)
        

    }
    
    @IBAction func resumeAction(sender: AnyObject) {
        
        print("sleep 10 second...")
        NSThread.sleepForTimeInterval(10)
        
        print("resume...")
        dispatch_resume(queue)
    }
    
    
}

