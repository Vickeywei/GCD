//
//  main.m
//  目标队列
//
//  Created by 魏琦 on 16/7/26.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

#import <Foundation/Foundation.h>
void makeCall(dispatch_queue_t queue,NSString* caller,NSArray*callees) {
    NSInteger targetIndex = arc4random() % callees.count;
    NSString *callee = callees[targetIndex];
    
    NSLog(@"%@ is calling %@...", caller, callee);
    sleep(1);
    NSLog(@"...%@ is done calling %@.", caller, callee);
    
    // Wait some random time and call again
    //NSEC_PER_MSEC代表一毫秒包含多少纳秒;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (arc4random() % 1000) * NSEC_PER_MSEC), queue, ^{
        makeCall(queue, caller, callees);
    });
}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
      
        /**
         *  2016-07-26 14:45:52.771 目标队列[98094:3194723] Jack is calling Irma...
         2016-07-26 14:45:52.771 目标队列[98094:3194722] Joe is calling Irene...
         2016-07-26 14:45:52.771 目标队列[98094:3194724] Jill is calling Irene...
         可以看到一个任务还没有结束,另外一个任务已经开始了
         */
//        NSArray *house1Folks = @[@"Joe", @"Jack", @"Jill"];
//        NSArray *house2Folks = @[@"Irma", @"Irene", @"Ian"];
//        
//        dispatch_queue_t house1Queue = dispatch_queue_create("house 1", DISPATCH_QUEUE_CONCURRENT);
//        
//        for (NSString *caller in house1Folks) {
//            dispatch_async(house1Queue, ^{
//                makeCall(house1Queue, caller, house2Folks);
//            });
//        }
//    }
//    dispatch_main();
        NSArray *house1Folks = @[@"Joe", @"Jack", @"Jill"];
        NSArray *house2Folks = @[@"Irma", @"Irene", @"Ian"];
        dispatch_queue_t house1Queue = dispatch_queue_create("house 1", DISPATCH_QUEUE_CONCURRENT);
        
        // Set the target queue
        dispatch_queue_t partyLine = dispatch_queue_create("party line", DISPATCH_QUEUE_SERIAL);
        dispatch_set_target_queue(house1Queue, partyLine);
        
        for (NSString *caller in house1Folks) {
            dispatch_async(house1Queue, ^{
                makeCall(house1Queue, caller, house2Folks);
            });
        }
    }
    dispatch_main();
    
    return 0;
}

