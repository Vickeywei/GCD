//
//  ViewController.swift
//  目标队列1
//
//  Created by 魏琦 on 16/7/26.
//  Copyright © 2016年 com.drcacom.com. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let serailQueue = dispatch_queue_create("com.serail.queue", DISPATCH_QUEUE_SERIAL)
    let concurremtQueue = dispatch_queue_create("com.concurrent.queue", DISPATCH_QUEUE_CONCURRENT)
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func action1(sender: AnyObject) {
        //现在回开辟新的线程去执行这段任务
        dispatch_async(concurremtQueue) { 
            for _ in 1...1000 {
            
                print("123",NSThread.currentThread())
            }
            
        }
        
        dispatch_async(concurremtQueue) {
            print("789",NSThread.currentThread())
            
            
        }
        
        dispatch_async(concurremtQueue) {
            print("456",NSThread.currentThread())
            
        }
    }
    
    
    @IBAction func action2(sender: AnyObject) {
        //让他串行执行
        dispatch_set_target_queue(concurremtQueue, serailQueue)
        dispatch_async(concurremtQueue) {
            for _ in 1...1000 {
                print("123",NSThread.currentThread())
            }
            
        }
        
        dispatch_async(concurremtQueue) {
            print("789",NSThread.currentThread())
            
            
        }
        
        dispatch_async(concurremtQueue) {
            print("456",NSThread.currentThread())
            
        }
    }

}

